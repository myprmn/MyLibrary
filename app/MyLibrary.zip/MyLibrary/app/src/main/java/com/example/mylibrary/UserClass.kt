package com.example.mylibrary

class UserClass (
    val email : String? = null,
    val name : String? = null,
    val uuid : String? = null
        )