package com.example.mylibrary

class DataModel(
    val namaBuku: String? = null,
    val penerbit: String? = null,
    val tahunTerbit: String? = null,
    val penulis: String? = null,
    val coverBuku: String? = null
)